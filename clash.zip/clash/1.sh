cd /root/.config
mkdir clash
cd clash
wget https://github.com/ghcyg/-r-/raw/main/clash.zip
unzip clash.zip 
cd
cd /root/.config
chmod -R 777 clash
cd /root/.config/clash
